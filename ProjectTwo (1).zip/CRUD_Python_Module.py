"""
CRUD_Python_Module.py
CS 340 Module Four Milestone

Portable Python module that provides Create and Read functionality for a
MongoDB database/collection using PyMongo.
"""

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class CRUD:
    """MongoDB CRUD helper class for the AAC animals collection."""

    def __init__(self, username, password, host="localhost", port=27017,
                 database="aac", collection="animals", auth_source="admin"):
        """
        Initialize a MongoDB client and connect to the specified database
        and collection.
        """
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.database_name = database
        self.collection_name = collection
        self.auth_source = auth_source

        # Build the authenticated MongoDB connection string.
        self.client = MongoClient(
            f"mongodb://{username}:{password}@{host}:{port}/?authSource={auth_source}"
        )
        self.database = self.client[database]
        self.collection = self.database[collection]

    def create(self, data):
        """
        Insert a document into the MongoDB collection.

        Args:
            data (dict): A document containing key/value pairs to insert.

        Returns:
            bool: True if the insert succeeds, otherwise False.
        """
        if data is not None and isinstance(data, dict):
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except PyMongoError as error:
                print(f"Insert failed: {error}")
                return False
        return False

    def read(self, query):
        """
        Query documents from the MongoDB collection using find().

        Args:
            query (dict): A MongoDB query document.

        Returns:
            list: Matching documents if successful, otherwise an empty list.
        """
        if query is not None and isinstance(query, dict):
            try:
                return list(self.collection.find(query))
            except PyMongoError as error:
                print(f"Read failed: {error}")
                return []
        return []
